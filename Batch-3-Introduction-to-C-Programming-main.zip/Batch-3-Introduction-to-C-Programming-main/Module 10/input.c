#include<stdio.h>
int main()
{
    char a[18];
    scanf("%s",&a);
    printf("%s\n",a);
    return 0;
}