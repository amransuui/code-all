#include<stdio.h>
int main()
{
    char a[5];
    int sz=sizeof(a)/sizeof(char);
    printf("%d",sizeof(a));
    return 0;
}