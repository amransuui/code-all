#include<stdio.h>
int main()
{
    printf("Hello World\t\t\tNew Tab e Jao");
    printf("Hello World");
    return 0;
}

// \n - new line 
// \t - tab            
// Hello World
// Now I am a programmer