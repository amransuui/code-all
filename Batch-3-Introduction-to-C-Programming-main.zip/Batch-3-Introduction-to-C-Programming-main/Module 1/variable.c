#include<stdio.h>
int main()
{
    int rahim=10;
    float karim=10000.52;
    char habib='Z';
    printf("%0.1f",karim);
    return 0;
}